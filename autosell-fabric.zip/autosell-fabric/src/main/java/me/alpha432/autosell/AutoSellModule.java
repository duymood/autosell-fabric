package me.alpha432.autosell;

import me.alpha432.autosell.util.Setting;
import me.alpha432.autosell.util.Timer;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.slot.Slot;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.text.Text;

/**
 * Standalone port of me.alpha432.anbatukang.features.modules.misc.AutoSellModule.
 * <p>
 * Behaviour is unchanged from the original: sends a configurable chat/sell
 * command, waits for the resulting shop GUI, quick-moves every item from the
 * player's inventory/hotbar into it, closes the screen, waits a delay, and
 * repeats while enabled.
 */
public class AutoSellModule {

    private final Setting<Boolean> requireConfirm = new Setting<>("RequireConfirm", true);
    private final Setting<String> sellCommand = new Setting<>("Command", "sell");
    private final Setting<Float> delaySetting = new Setting<>("Delay", 2.0F);

    private enum State {
        SEND_CMD,
        WAIT_GUI,
        PUT_ITEMS,
        WAIT_DELAY
    }

    private State state = State.SEND_CMD;
    private final Timer timer = new Timer();
    private final Timer confirmTimer = new Timer();
    private boolean awaitingConfirmation = false;
    private boolean enabled = false;

    public boolean isEnabled() {
        return enabled;
    }

    public Setting<Boolean> requireConfirmSetting() {
        return requireConfirm;
    }

    public Setting<String> sellCommandSetting() {
        return sellCommand;
    }

    public Setting<Float> delaySetting() {
        return delaySetting;
    }

    /** Call when the user runs the toggle command. */
    public void toggle() {
        if (enabled) {
            disable();
        } else {
            enable();
        }
    }

    public void enable() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (requireConfirm.getValue() && !awaitingConfirmation) {
            sendMessage(Text.literal("§eWarning! This will sell every item in your inventory. "
                    + "Only use this with an empty inventory - run the command again to confirm."));
            awaitingConfirmation = true;
            confirmTimer.reset();
            return;
        }

        awaitingConfirmation = false;
        state = State.SEND_CMD;
        timer.reset();
        enabled = true;
        sendMessage(Text.literal("§aAutoSell enabled - selling all items!"));
    }

    public void disable() {
        enabled = false;
    }

    /** Call this every client tick while the mod is loaded. */
    public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null) {
            return;
        }

        if (awaitingConfirmation && confirmTimer.passedMs(3000L)) {
            awaitingConfirmation = false;
            sendMessage(Text.literal("§cAutoSell confirmation timeout - cancelled."));
        }

        if (!enabled) {
            return;
        }

        switch (state) {
            case SEND_CMD -> {
                String cmd = sellCommand.getValue();
                if (cmd.startsWith("/")) {
                    cmd = cmd.substring(1);
                }
                mc.player.networkHandler.sendChatCommand(cmd);
                state = State.WAIT_GUI;
                timer.reset();
            }
            case WAIT_GUI -> {
                Screen current = mc.currentScreen;
                if (current instanceof HandledScreen<?> && !(current instanceof InventoryScreen)) {
                    state = State.PUT_ITEMS;
                    timer.reset();
                } else if (timer.passedMs(5000L)) {
                    // Shop never opened (bad command, no shop, etc.) - stop retrying forever.
                    state = State.SEND_CMD;
                }
            }
            case PUT_ITEMS -> {
                if (mc.player.currentScreenHandler != null) {
                    for (Slot slot : mc.player.currentScreenHandler.slots) {
                        if (slot.inventory == mc.player.getInventory()) {
                            int slotIndex = slot.getIndex();
                            if (slotIndex >= 0 && slotIndex < 36) {
                                ItemStack stack = slot.getStack();
                                if (!stack.isEmpty()) {
                                    mc.interactionManager.clickSlot(
                                            mc.player.currentScreenHandler.syncId,
                                            slot.id,
                                            0,
                                            SlotActionType.QUICK_MOVE,
                                            mc.player
                                    );
                                }
                            }
                        }
                    }
                    mc.player.closeHandledScreen();
                    state = State.WAIT_DELAY;
                    timer.reset();
                } else {
                    state = State.SEND_CMD;
                }
            }
            case WAIT_DELAY -> {
                if (timer.passedMs((long) (delaySetting.getValue() * 1000.0F))) {
                    state = State.SEND_CMD;
                }
            }
        }
    }

    private void sendMessage(Text text) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player != null) {
            mc.player.sendMessage(text, false);
        }
    }
}
