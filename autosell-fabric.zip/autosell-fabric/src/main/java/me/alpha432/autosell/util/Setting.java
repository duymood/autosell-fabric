package me.alpha432.autosell.util;

/**
 * Minimal standalone stand-in for the original framework's Setting&lt;T&gt;.
 * The full anbatukang client persists/renders these through a ClickGui and
 * a ConfigManager; this standalone mod just needs a typed, mutable value
 * holder, so it's trimmed down to that.
 */
public class Setting<T> {
    private final String name;
    private final T defaultValue;
    private T value;

    public Setting(String name, T defaultValue) {
        this.name = name;
        this.defaultValue = defaultValue;
        this.value = defaultValue;
    }

    public String getName() {
        return name;
    }

    public T getValue() {
        return value;
    }

    public void setValue(T value) {
        this.value = value;
    }

    public T getDefaultValue() {
        return defaultValue;
    }
}
