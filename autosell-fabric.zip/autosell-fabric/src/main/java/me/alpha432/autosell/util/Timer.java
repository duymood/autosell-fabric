package me.alpha432.autosell.util;

/**
 * Simple stopwatch-style timer, ported unchanged from the original
 * anbatukang util.models.Timer class.
 */
public class Timer {
    private long time = -1L;

    public boolean passedMs(long ms) {
        return getMs(System.nanoTime() - this.time) >= ms;
    }

    public void reset() {
        this.time = System.nanoTime();
    }

    private long getMs(long time) {
        return time / 1_000_000L;
    }
}
