package me.alpha432.autosell;

import com.mojang.brigadier.arguments.FloatArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.text.Text;

import static com.mojang.brigadier.arguments.FloatArgumentType.getFloat;
import static com.mojang.brigadier.arguments.StringArgumentType.getString;
import static net.fabricmc.fabric.api.client.command.v2.ClientCommandManager.argument;
import static net.fabricmc.fabric.api.client.command.v2.ClientCommandManager.literal;

/**
 * Standalone Fabric client entrypoint for the AutoSell feature that was
 * extracted from the anbatukang client base. Registers:
 * <p>
 * /autosell toggle          - enable/disable
 * /autosell command <name>  - the sell command to run each cycle (default "sell")
 * /autosell delay <seconds> - delay between sell cycles (default 2.0)
 * /autosell confirm         - skip the safety warning (equivalent to RequireConfirm=false)
 */
public class AutoSellMod implements ClientModInitializer {

    private final AutoSellModule module = new AutoSellModule();

    @Override
    public void onInitializeClient() {
        ClientTickEvents.END_CLIENT_TICK.register(client -> module.onTick());

        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) -> {
            dispatcher.register(literal("autosell")
                    .then(literal("toggle").executes(ctx -> {
                        module.toggle();
                        ctx.getSource().sendFeedback(Text.literal(
                                "AutoSell is now " + (module.isEnabled() ? "ON" : "OFF")));
                        return 1;
                    }))
                    .then(literal("command").then(argument("name", StringArgumentType.string()).executes(ctx -> {
                        String name = getString(ctx, "name");
                        module.sellCommandSetting().setValue(name);
                        ctx.getSource().sendFeedback(Text.literal("AutoSell command set to: " + name));
                        return 1;
                    })))
                    .then(literal("delay").then(argument("seconds", FloatArgumentType.floatArg(0.5F, 10.0F)).executes(ctx -> {
                        float seconds = getFloat(ctx, "seconds");
                        module.delaySetting().setValue(seconds);
                        ctx.getSource().sendFeedback(Text.literal("AutoSell delay set to: " + seconds + "s"));
                        return 1;
                    })))
                    .then(literal("confirm").executes(ctx -> {
                        module.requireConfirmSetting().setValue(!module.requireConfirmSetting().getValue());
                        ctx.getSource().sendFeedback(Text.literal(
                                "AutoSell confirmation requirement: "
                                        + (module.requireConfirmSetting().getValue() ? "ON" : "OFF")));
                        return 1;
                    }))
            );
        });
    }
}
